package simpleVisitorPattern.visitor;

import simpleVisitorPattern.part.Body;
import simpleVisitorPattern.part.Engine;
import simpleVisitorPattern.part.Wheel;
import simpleVisitorPattern.part.Brake;



public class MyReverseVisitor extends CarPartVisitor {
   public void visit(Wheel part) {
      String reverseName =  reverse(part.getName());
      part.setName(reverseName);
   }

   public void visit(Engine part) {
	   String reverseName =  reverse(part.getName()); 
	   part.setName(reverseName);
   }

   public void visit(Body part) {
	   String reverseName =  reverse(part.getName()); 
	   part.setName(reverseName);
   }
   
   public void visit(Brake part) {
	   String reverseName =  reverse(part.getName()); 
	   part.setName(reverseName);
   }
   
   private String reverse (String partName) {
	   String reversed = "";
	   for (String part : partName.split(" ")) {
		   reversed += new StringBuilder(part).reverse().toString();
		   reversed += " ";
	   }
	   return reversed;
   }

}
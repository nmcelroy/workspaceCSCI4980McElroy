 
package handler;

import org.eclipse.e4.core.di.annotations.Execute;

public class MoveTopHandler {
	@Execute
	public void execute() {
		
	}
		
}